package com.haessal.kkoko

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val s = Store.s(ctx)
        Store.catchUp(ctx)
        val id = intent.getStringExtra("id")
        val a = s.alarms.find { it.id == id }
        if (a != null && a.on) {
            if (a.type == "일정") a.on = false
            Store.save()
            if (s.stage != "egg") {
                try {
                    ctx.startForegroundService(
                        Intent(ctx, PetService::class.java)
                            .setAction(PetService.ACT_RING)
                            .putExtra("id", a.id)
                    )
                } catch (_: Exception) {
                }
            }
        }
        AlarmSched.schedule(ctx, System.currentTimeMillis() + 30_000)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val s = Store.s(ctx)
        AlarmSched.schedule(ctx)
        if (s.petOn && Settings.canDrawOverlays(ctx)) {
            try {
                ctx.startForegroundService(Intent(ctx, PetService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
