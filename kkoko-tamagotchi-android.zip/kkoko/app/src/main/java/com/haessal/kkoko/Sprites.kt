package com.haessal.kkoko

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/** 64×64 좌표계로 알·병아리·수탉을 그린다 */
object Sprites {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = RectF()

    private fun col(hex: String): Int = Color.parseColor(hex)

    private fun fill(c: Int) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = c
    }

    private fun stroke(c: Int, w: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE
        p.color = c
        p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
    }

    private fun ellipse(cv: Canvas, cx: Float, cy: Float, rx: Float, ry: Float) {
        oval.set(cx - rx, cy - ry, cx + rx, cy + ry)
        cv.drawOval(oval, p)
    }

    private fun shadow(cv: Canvas) {
        fill(0x2E000000)
        ellipse(cv, 32f, 60f, 15f, 3f)
    }

    fun egg(cv: Canvas, mult: Double, cracked: Boolean) {
        val c0: Int
        val c1: Int
        when {
            mult < 0.8 -> { c0 = col("#FFF1B8"); c1 = col("#F2C230") }
            mult > 1.2 -> { c0 = col("#F3EEE6"); c1 = col("#C8BBA6") }
            else -> { c0 = col("#FFFAF1"); c1 = col("#E6D5B8") }
        }
        shadow(cv)
        path.reset()
        path.moveTo(32f, 6f)
        path.cubicTo(46f, 6f, 52f, 30f, 52f, 40f)
        path.cubicTo(52f, 52f, 43f, 59f, 32f, 59f)
        path.cubicTo(21f, 59f, 12f, 52f, 12f, 40f)
        path.cubicTo(12f, 30f, 18f, 6f, 32f, 6f)
        path.close()
        fill(c1)
        p.shader = RadialGradient(24f, 20f, 48f, c0, c1, Shader.TileMode.CLAMP)
        cv.drawPath(path, p)
        stroke(col("#B8A685"), 1f)
        cv.drawPath(path, p)

        fill(0x8CD4BF98.toInt())
        cv.drawCircle(23f, 30f, 3f, p)
        cv.drawCircle(40f, 44f, 2.4f, p)
        cv.drawCircle(36f, 22f, 1.8f, p)

        cv.save()
        cv.rotate(20f, 25f, 20f)
        fill(0x8CFFFFFF.toInt())
        ellipse(cv, 25f, 20f, 4f, 7f)
        cv.restore()

        if (mult < 0.8) {
            fill(col("#FFFFFF"))
            star(cv, 33f, 38f, 4f)
        }
        if (cracked) {
            stroke(col("#6B5A3E"), 1.6f)
            path.reset()
            path.moveTo(15f, 37f)
            val pts = floatArrayOf(20f, 33f, 24f, 38f, 29f, 32f, 33f, 37f, 38f, 32f, 43f, 36f, 48f, 33f)
            var i = 0
            while (i < pts.size) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
            cv.drawPath(path, p)
        }
    }

    private fun star(cv: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        path.moveTo(cx, cy - r)
        path.quadTo(cx, cy, cx + r, cy)
        path.quadTo(cx, cy, cx, cy + r)
        path.quadTo(cx, cy, cx - r, cy)
        path.quadTo(cx, cy, cx, cy - r)
        path.close()
        cv.drawPath(path, p)
    }

    fun chick(cv: Canvas, tier: String, wing: Float) {
        val body = col(when (tier) { "high" -> "#FFD23F"; "low" -> "#FFF0B8"; else -> "#FFE27A" })
        val dark = col(when (tier) { "high" -> "#F2B705"; "low" -> "#EAD98A"; else -> "#F5C842" })
        val sc = when (tier) { "high" -> 1.08f; "low" -> 0.84f; else -> 1f }
        cv.save()
        cv.scale(sc, sc, 32f, 60f)
        shadow(cv)
        stroke(col("#E8891C"), 2.5f)
        cv.drawLine(26f, 51f, 26f, 58f, p); cv.drawLine(23f, 58f, 29f, 58f, p)
        cv.drawLine(35f, 51f, 35f, 58f, p); cv.drawLine(32f, 58f, 38f, 58f, p)

        fill(body)
        ellipse(cv, 30f, 41f, 18f, 14.5f)
        cv.drawCircle(40f, 25f, 12f, p)

        stroke(dark, 2f)
        path.reset()
        path.moveTo(38f, 13f)
        path.quadTo(40f, 7f, 42f, 12f)
        path.quadTo(44f, 7f, 46f, 13f)
        cv.drawPath(path, p)

        cv.save()
        cv.rotate(-18f + wing, 31f, 37f)
        fill(dark)
        ellipse(cv, 25f, 40f, 9.5f, 6f)
        cv.restore()

        fill(col("#1F2937")); cv.drawCircle(44f, 23f, 2.3f, p)
        fill(Color.WHITE); cv.drawCircle(44.8f, 22.2f, 0.8f, p)
        fill(col("#F59E0B"))
        path.reset(); path.moveTo(51f, 25f); path.lineTo(58f, 27f); path.lineTo(51f, 30f); path.close()
        cv.drawPath(path, p)
        fill(0x8CFF8FA0.toInt()); ellipse(cv, 42f, 30f, 2.6f, 1.5f)
        cv.restore()
    }

    fun rooster(cv: Canvas, tier: String, wing: Float) {
        val tail = when (tier) {
            "high" -> arrayOf("#14532D", "#1D7A55", "#C2410C")
            "low" -> arrayOf("#A8A29E", "#CFCAC5", "#E7E5E4")
            else -> arrayOf("#3F3F46", "#57534E", "#A16207")
        }
        val sc = when (tier) { "high" -> 1.1f; "low" -> 0.84f; else -> 1f }
        val cs = when (tier) { "high" -> 1.25f; "low" -> 0.75f; else -> 1f }
        cv.save()
        cv.scale(sc, sc, 32f, 60f)
        shadow(cv)
        stroke(col("#E8A31C"), 2.6f)
        cv.drawLine(28f, 49f, 28f, 58f, p); cv.drawLine(25f, 58f, 31f, 58f, p)
        cv.drawLine(36f, 49f, 36f, 58f, p); cv.drawLine(33f, 58f, 39f, 58f, p)

        fill(col(tail[0]))
        path.reset(); path.moveTo(19f, 40f); path.cubicTo(6f, 30f, 7f, 12f, 15f, 8f)
        path.cubicTo(15f, 21f, 19f, 28f, 23f, 32f); path.close(); cv.drawPath(path, p)
        fill(col(tail[1]))
        path.reset(); path.moveTo(20f, 38f); path.cubicTo(4f, 35f, 2f, 22f, 8f, 17f)
        path.cubicTo(10f, 28f, 16f, 32f, 23f, 34f); path.close(); cv.drawPath(path, p)
        fill(col(tail[2]))
        path.reset(); path.moveTo(20f, 43f); path.cubicTo(9f, 43f, 5f, 34f, 7f, 30f)
        path.cubicTo(11f, 36f, 16f, 38f, 23f, 38f); path.close(); cv.drawPath(path, p)

        fill(Color.WHITE); ellipse(cv, 32f, 40f, 15.5f, 12f)
        stroke(col("#E5E5E5"), 1f); ellipse(cv, 32f, 40f, 15.5f, 12f)

        path.reset(); path.moveTo(37f, 35f); path.cubicTo(37f, 27f, 39f, 18f, 44f, 15.5f)
        path.cubicTo(50f, 14f, 53f, 19f, 51f, 26f); path.cubicTo(49f, 32f, 47f, 36f, 45f, 41f); path.close()
        fill(Color.WHITE); cv.drawPath(path, p)
        stroke(col("#E5E5E5"), 1f); cv.drawPath(path, p)

        cv.save()
        cv.scale(cs, cs, 45f, 15f)
        fill(col("#E11D48"))
        path.reset(); path.moveTo(40f, 15f)
        path.quadTo(40f, 8f, 43f, 13f)
        path.quadTo(45f, 6f, 47f, 12f)
        path.quadTo(49f, 6f, 51f, 13f)
        path.quadTo(52f, 15f, 50f, 16f)
        path.quadTo(45f, 17f, 40f, 15f)
        path.close(); cv.drawPath(path, p)
        cv.restore()

        fill(col("#E11D48"))
        path.reset(); path.moveTo(49f, 24f); path.quadTo(52f, 29f, 48f, 31f); path.quadTo(46f, 28f, 49f, 24f)
        path.close(); cv.drawPath(path, p)

        fill(col("#1F2937")); cv.drawCircle(46f, 20f, 1.9f, p)
        fill(Color.WHITE); cv.drawCircle(46.6f, 19.4f, 0.6f, p)
        fill(col("#F59E0B"))
        path.reset(); path.moveTo(51f, 19f); path.lineTo(57.5f, 21f); path.lineTo(51f, 23.3f); path.close()
        cv.drawPath(path, p)

        cv.save()
        cv.rotate(wing, 35f, 36f)
        path.reset(); path.moveTo(23f, 38f); path.cubicTo(27f, 32f, 38f, 33f, 39f, 40f)
        path.cubicTo(37f, 46f, 28f, 47f, 23f, 42f); path.close()
        fill(col("#F3F3F3")); cv.drawPath(path, p)
        stroke(col("#DDDDDD"), 1f); cv.drawPath(path, p)
        cv.restore()
        cv.restore()
    }
}
