package com.haessal.kkoko

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import kotlin.math.ceil

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var statusTv: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private val s: PetState get() = Store.s(this)

    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            h.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#BFE3FF")
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#F4F8FC"))
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dpi(18), dpi(18), dpi(18), dpi(40))
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        build()
        h.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(ticker)
    }

    // ---------- UI 도우미 ----------
    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = dp(16f)
        c.background = bg
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(12)
        root.addView(c, lp)
        return c
    }

    private fun title(parent: LinearLayout, t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 16f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setTextColor(Color.parseColor("#1F2937"))
        tv.setPadding(0, 0, 0, dpi(6))
        parent.addView(tv)
    }

    private fun note(parent: LinearLayout, t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 13f
        tv.setTextColor(Color.parseColor("#64748B"))
        tv.setLineSpacing(0f, 1.25f)
        tv.setPadding(0, dpi(4), 0, dpi(4))
        parent.addView(tv)
        return tv
    }

    private fun button(parent: LinearLayout, t: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 14f
        if (primary) {
            val bg = GradientDrawable()
            bg.setColor(Color.parseColor("#F59E0B"))
            bg.cornerRadius = dp(12f)
            b.background = bg
            b.setTextColor(Color.WHITE)
        }
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpi(6)
        parent.addView(b, lp)
        return b
    }

    private fun switchRow(parent: LinearLayout, t: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = t
        sw.textSize = 14.5f
        sw.isChecked = checked
        sw.setPadding(0, dpi(8), 0, dpi(8))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        parent.addView(sw)
    }

    // ---------- 화면 구성 ----------
    private fun build() {
        Store.catchUp(this)
        root.removeAllViews()

        val head = TextView(this)
        head.text = "🐣 꼬꼬 다마고찌"
        head.textSize = 24f
        head.setTypeface(null, Typeface.BOLD)
        head.setTextColor(Color.parseColor("#1F2937"))
        root.addView(head)

        // 상태
        val st = card()
        title(st, "📊 지금 상태")
        statusTv = note(st, "")
        statusTv?.setTextColor(Color.parseColor("#334155"))
        statusTv?.textSize = 14f
        refreshStatus()

        // 권한 및 실행
        val run = card()
        title(run, "🚀 바탕화면에 띄우기")
        val overlayOk = Settings.canDrawOverlays(this)
        if (!overlayOk) {
            note(run, "펫이 바탕화면 위를 돌아다니려면 ‘다른 앱 위에 표시’ 권한이 필요해요.")
            button(run, "① 다른 앱 위에 표시 허용하기", true) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            button(run, "② 알림 권한 허용하기 (알람 표시용)") {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
            button(run, "③ 배터리 최적화 제외 (펫이 사라지지 않게)") {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }
        if (overlayOk) {
            if (!PetService.running) {
                button(run, "🐥 펫을 바탕화면에 띄우기", true) {
                    s.petOn = true
                    Store.save()
                    startForegroundService(Intent(this, PetService::class.java))
                    goHome()
                }
            } else {
                button(run, "🏠 바탕화면으로 가서 보기", true) { goHome() }
                button(run, "펫 숨기기") {
                    startService(Intent(this, PetService::class.java).setAction(PetService.ACT_HIDE))
                    h.postDelayed({ build() }, 400)
                }
            }
        }
        note(
            run,
            "• 알: 톡 치면 진동으로 고마워해요(정성 +4) · 드래그로 이동 · 길게 누르면 이 화면\n" +
                    "• 병아리/닭: 톡 치면 쓰다듬기(+3) 후 날아가요 · 길게 누르면 먹이(+8) · 드래그로 이동\n" +
                    "• 알림창의 ‘🌾 먹이 주기’ 버튼으로도 먹이를 줄 수 있어요"
        )

        // 보이기 설정
        val vis = card()
        title(vis, "🏠 보이는 곳")
        switchRow(vis, "홈 화면(바탕화면)에서만 보이기", s.homeOnly) { v ->
            s.homeOnly = v
            Store.save()
            if (v && !Util.hasUsage(this)) {
                Toast.makeText(this, "목록에서 ‘꼬꼬 다마고찌’를 찾아 사용 기록 접근을 허용해 주세요", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        note(
            vis,
            if (s.homeOnly && !Util.hasUsage(this)) "⚠️ ‘사용 기록 접근’ 권한이 없어 지금은 모든 화면에서 보여요."
            else "끄면 다른 앱을 쓸 때도 펫이 화면 위에 떠 있어요. 켜면 앱을 실행하는 동안 숨었다가 바탕화면으로 돌아오면 다시 나타나요."
        )

        // 소리·진동
        val snd = card()
        title(snd, "🔊 소리 · 진동")
        switchRow(snd, "소리 (병아리 ‘삐약’ · 닭 ‘꼬끼오’)", s.sound) { v -> s.sound = v; Store.save() }
        switchRow(snd, "진동", s.vib) { v -> s.vib = v; Store.save() }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        snd.addView(row)
        fun small(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.isAllCaps = false
            b.setOnClickListener { f() }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        small("삐약 듣기") { Sound.play(rooster = false, alarm = false) }
        small("꼬끼오 듣기") { Sound.play(rooster = true, alarm = false) }
        small("진동") { Util.vibrate(this, longArrayOf(0, 200, 100, 200)) }

        // 알림
        val al = card()
        title(al, "⏰ 알람 · 일정 · 기상")
        if (s.stage == "egg") note(al, "🥚 알 상태에서는 시계만 보여요. 병아리가 되면 등록한 알림이 울려요.")
        if (s.alarms.isEmpty()) note(al, "등록된 알림이 없어요.")
        for (a in s.alarms.toList()) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, dpi(6), 0, dpi(6))
            val tv = TextView(this)
            val date = if (a.type == "일정" && a.date.length >= 10) a.date.substring(5).replace("-", "/") + " " else ""
            tv.text = "${Store.ICON[a.type] ?: ""} $date${a.time}  ${a.label.ifEmpty { a.type }}"
            tv.textSize = 15f
            tv.setTextColor(if (a.on) Color.parseColor("#1F2937") else Color.parseColor("#94A3B8"))
            r.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val sw = Switch(this)
            sw.isChecked = a.on
            sw.setOnCheckedChangeListener { _, v ->
                a.on = v
                Store.save()
                AlarmSched.schedule(this)
                build()
            }
            r.addView(sw)
            val del = Button(this)
            del.text = "삭제"
            del.isAllCaps = false
            del.setOnClickListener {
                s.alarms.remove(a)
                Store.save()
                AlarmSched.schedule(this)
                build()
            }
            r.addView(del)
            al.addView(r)
        }
        button(al, "+ 알림 추가", true) { addAlarm() }
        note(al, "기상·알람은 매일, 일정은 정한 날 한 번 울려요. 펫을 터치하거나 알림창의 ‘끄기’로 멈춰요. 폰이 잠겨 있어도 울려요.")

        // 성장 속도
        val sp = card()
        title(sp, "⏱ 성장 속도")
        val rg = RadioGroup(this)
        for ((k, name) in Store.SPEED_NAME) {
            val rb = RadioButton(this)
            rb.text = name
            rb.textSize = 14f
            rb.id = View.generateViewId()
            rb.tag = k
            rg.addView(rb)
            if (s.speed == k) rb.isChecked = true
        }
        rg.setOnCheckedChangeListener { g, id ->
            val k = g.findViewById<RadioButton>(id)?.tag as? String
            if (k != null) { s.speed = k; Store.save() }
        }
        sp.addView(rg)

        // 초기화
        val rs = card()
        title(rs, "🔄 처음부터")
        button(rs, "새 알로 다시 키우기") {
            AlertDialog.Builder(this)
                .setTitle("처음부터 다시 키울까요?")
                .setMessage("지금 키우는 펫이 사라지고 새 알이 생겨요. 알림과 설정은 그대로예요.")
                .setPositiveButton("다시 키우기") { _, _ ->
                    Store.reset(this)
                    if (PetService.running) startService(Intent(this, PetService::class.java).setAction(PetService.ACT_REFRESH))
                    build()
                }
                .setNegativeButton("취소", null)
                .show()
        }
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun pad(n: Int) = n.toString().padStart(2, '0')

    private fun fmt(ms: Double): String {
        var sec = maxOf(0L, ceil(ms / 1000).toLong())
        val d = sec / 86400; sec %= 86400
        val hh = sec / 3600
        val mm = (sec % 3600) / 60
        val ss = sec % 60
        return if (d > 0) "${d}일 ${hh}시간 ${mm}분" else if (hh > 0) "${hh}시간 ${mm}분 ${ss}초" else "${mm}분 ${ss}초"
    }

    private fun refreshStatus() {
        val tv = statusTv ?: return
        Store.catchUp(this)
        val g = if (s.stage == "egg") "정성" else "애정"
        val a = Store.avg(s)
        val r = Store.remainMs(s)
        val what = when (s.stage) { "egg" -> "부화"; "chick" -> "성체"; else -> "산란" }
        val pred = when (s.stage) {
            "egg" -> Store.tierName("chick", Store.tierOf(a))
            "chick" -> Store.tierName("rooster", Store.tierOf(a))
            else -> "다음 알 부화 속도 ×%.2f".format(1.5 - a / 100)
        }
        val sb = StringBuilder()
        sb.append("${s.gen}세대 · ${Store.stageName(s)}\n")
        sb.append("지금 $g ${s.gauge.toInt()} / 평균 $g ${a.toInt()}\n")
        sb.append("$what까지 ")
        sb.append(if (s.stage == "egg" && r <= 0 && s.stim < 5) "자극이 더 필요해요 (톡톡)" else fmt(r))
        sb.append("\n")
        if (s.stage == "egg") {
            sb.append("자극 ${s.stim}회 (최소 5회) · 이 알의 부화 속도 ×${s.mult}\n")
        }
        sb.append("예상 결과: $pred\n")
        sb.append("※ 단계가 끝날 때의 평균 ${g}으로 발육이 정해져요 (70↑ 최상 · 40↑ 보통 · 그 아래 허약)")
        tv.text = sb.toString()
    }

    // ---------- 알림 추가 ----------
    private fun addAlarm() {
        val types = arrayOf("기상", "알람", "일정")
        AlertDialog.Builder(this)
            .setTitle("어떤 알림인가요?")
            .setItems(arrayOf("🌅 기상 (매일)", "⏰ 알람 (매일)", "📅 일정 (하루)")) { _, which ->
                pickTime(types[which])
            }
            .show()
    }

    private fun pickTime(type: String) {
        TimePickerDialog(this, { _, hh, mm ->
            val time = "${pad(hh)}:${pad(mm)}"
            if (type == "일정") pickDate(type, time) else askLabel(type, time, "")
        }, 7, 0, true).show()
    }

    private fun pickDate(type: String, time: String) {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            askLabel(type, time, "$y-${pad(m + 1)}-${pad(d)}")
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun askLabel(type: String, time: String, date: String) {
        val et = EditText(this)
        et.hint = "예: 1교시 수업, 회의 (비워도 돼요)"
        et.setSingleLine()
        val box = LinearLayout(this)
        box.setPadding(dpi(20), dpi(8), dpi(20), 0)
        box.addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle("내용 ($type $time)")
            .setView(box)
            .setPositiveButton("추가") { _, _ ->
                s.alarms.add(Alarm(System.currentTimeMillis().toString(36), type, time, date, et.text.toString().trim().take(20), true))
                s.alarms.sortBy { it.time }
                Store.save()
                AlarmSched.schedule(this)
                build()
                Toast.makeText(this, "알림을 추가했어요", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }
}
