package com.haessal.kkoko

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

class PetService : Service() {
    companion object {
        const val ACT_RING = "com.haessal.kkoko.RING"
        const val ACT_STOPRING = "com.haessal.kkoko.STOPRING"
        const val ACT_FEED = "com.haessal.kkoko.FEED"
        const val ACT_HIDE = "com.haessal.kkoko.HIDE"
        const val ACT_REFRESH = "com.haessal.kkoko.REFRESH"
        const val CH_PET = "pet"
        const val CH_ALARM = "alarm2"
        const val NOTI_PET = 1
        const val NOTI_RING = 2

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private var petView: PetView? = null
    private var textView: TextOverlay? = null
    private var seedView: SeedView? = null
    private var petLp: WindowManager.LayoutParams? = null
    private var textLp: WindowManager.LayoutParams? = null
    private var seedLp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private val s: PetState get() = Store.s(this)

    private var petPx = 0
    private var topPad = 0
    private var textW = 0
    private var textH = 0
    private var seedPx = 0

    // 움직임
    private var px = 0f
    private var py = 0f
    private var mode = "idle"      // idle / walk / food / peck / fly
    private var t = 1f
    private var tx = 0f
    private var ty = 0f
    private var face = 1f
    private var fx0 = 0f
    private var fy0 = 0f
    private var fk = 0f
    private var fd = 1f
    private var lastPx = -9999
    private var lastPy = -9999

    // 먹이
    private var hasSeed = false
    private var seedX = 0f
    private var seedY = 0f

    // 터치
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startPx = 0f
    private var startPy = 0f
    private var moved = false
    private var longFired = false

    // 말풍선·알림
    private var tempText: String? = null
    private var tempUntil = 0L
    private var ringText: String? = null
    private var ringEnd = 0L
    private var lastBeat = 0L

    // 애니메이션 타이밍
    private var wobbleStart = 0L
    private var nextWobble = 0L
    private var shakeStart = 0L
    private var lastCare = 0L
    private var lastFrame = 0L
    private var lastSave = 0L

    // 홈 화면 감지
    private var lastFg: String? = null
    private var launcherPkg: String? = null
    private var shown = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        petPx = dpi(76)
        topPad = dpi(66)
        textW = dpi(290)
        textH = topPad + petPx + dpi(26)
        seedPx = dpi(34)
        createChannels()
        goForeground()
        Store.catchUp(this)
        Store.onEvent = { msg -> announce(msg) }
        launcherPkg = try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        } catch (_: Exception) {
            null
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        when (intent?.action) {
            ACT_HIDE -> {
                s.petOn = false
                Store.save()
                stopSelf()
                return START_NOT_STICKY
            }
            ACT_RING -> {
                ensureOverlay()
                startRing(intent.getStringExtra("id"))
            }
            ACT_STOPRING -> stopRing(false)
            ACT_FEED -> { ensureOverlay(); feed() }
            ACT_REFRESH -> {
                ensureOverlay()
                initPos()
                mode = "idle"; t = 1f
                removeSeed()
                petView?.invalidate()
            }
            else -> ensureOverlay()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        Store.onEvent = null
        s.x = px; s.y = py
        Store.save()
        for (v in listOf<View?>(seedView, textView, petView)) {
            try { if (v != null) wm.removeView(v) } catch (_: Exception) {}
        }
        petView = null; textView = null; seedView = null
        super.onDestroy()
    }

    // ---------------- 알림창 ----------------
    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        val pet = NotificationChannel(CH_PET, "펫 상주", NotificationManager.IMPORTANCE_LOW)
        pet.setShowBadge(false)
        nm.createNotificationChannel(pet)
        val al = NotificationChannel(CH_ALARM, "알람·일정·기상 알림", NotificationManager.IMPORTANCE_HIGH)
        al.setSound(null, null)
        al.enableVibration(false)
        nm.createNotificationChannel(al)
    }

    private fun svcIntent(action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            this, code, Intent(this, PetService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun openIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun buildNotif(): Notification {
        val icon = Icon.createWithResource(this, R.drawable.ic_stat)
        return Notification.Builder(this, CH_PET)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("꼬꼬 다마고찌")
            .setContentText("${Store.stageName(s)}를 돌보는 중 · 눌러서 설정")
            .setContentIntent(openIntent())
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, "🌾 먹이 주기", svcIntent(ACT_FEED, 11)).build())
            .addAction(Notification.Action.Builder(icon, "숨기기", svcIntent(ACT_HIDE, 12)).build())
            .build()
    }

    private fun goForeground() {
        val n = buildNotif()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTI_PET, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTI_PET, n)
        }
    }

    // ---------------- 오버레이 창 ----------------
    private fun ensureOverlay() {
        if (petView != null) return
        if (!Settings.canDrawOverlays(this)) return
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val pl = WindowManager.LayoutParams(
            petPx, petPx, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        pl.gravity = Gravity.TOP or Gravity.START
        val passFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val tl = WindowManager.LayoutParams(textW, textH, type, passFlags, PixelFormat.TRANSLUCENT)
        tl.gravity = Gravity.TOP or Gravity.START
        tl.alpha = 0.8f   // 안드로이드 12+ : 아래 앱으로 터치가 통과하려면 0.8 이하
        val sl = WindowManager.LayoutParams(seedPx, seedPx, type, passFlags, PixelFormat.TRANSLUCENT)
        sl.gravity = Gravity.TOP or Gravity.START
        sl.alpha = 0.8f
        petLp = pl; textLp = tl; seedLp = sl

        initPos()
        pl.x = px.toInt(); pl.y = py.toInt()
        tl.x = (px + petPx / 2f - textW / 2f).toInt(); tl.y = (py - topPad).toInt()

        try {
            val pv = PetView(this)
            pv.setOnTouchListener(touch)
            wm.addView(pv, pl)
            petView = pv
            val tv = TextOverlay(this, petPx, topPad)
            wm.addView(tv, tl)
            textView = tv
            val sv = SeedView(this)
            sv.visibility = View.GONE
            wm.addView(sv, sl)
            seedView = sv
        } catch (e: Exception) {
            return
        }
        lastFrame = SystemClock.uptimeMillis()
        nextWobble = System.currentTimeMillis() + 3000
        h.removeCallbacks(frame); h.removeCallbacks(tick)
        h.post(frame); h.post(tick)
    }

    private fun bounds(): FloatArray {
        val dm = resources.displayMetrics
        return floatArrayOf(
            0f, dp(90f),
            (dm.widthPixels - petPx).toFloat(),
            (dm.heightPixels - petPx - dpi(40)).toFloat()
        )
    }

    private fun clampX(v: Float): Float { val b = bounds(); return v.coerceIn(b[0], maxOf(b[0], b[2])) }
    private fun clampY(v: Float): Float { val b = bounds(); return v.coerceIn(b[1], maxOf(b[1], b[3])) }

    private fun initPos() {
        val dm = resources.displayMetrics
        px = if (s.x >= 0) clampX(s.x) else clampX((dm.widthPixels - petPx) / 2f)
        py = if (s.y >= 0) clampY(s.y) else clampY(dm.heightPixels * 0.42f)
        lastPx = -9999
    }

    // ---------------- 프레임 루프 ----------------
    private val frame = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = min(0.05f, (now - lastFrame) / 1000f)
            lastFrame = now
            move(dt)
            animate(System.currentTimeMillis())
            place()
            h.postDelayed(this, 33)
        }
    }

    private fun rnd(a: Float, b: Float): Float = a + Random.nextFloat() * (b - a)

    private fun pickTarget() {
        val b = bounds()
        tx = rnd(b[0], b[2]); ty = rnd(b[1], b[3])
    }

    private fun stepTo(dt: Float, sp: Float): Boolean {
        val dx = tx - px
        val dy = ty - py
        val d = hypot(dx, dy)
        if (abs(dx) > 2) face = if (dx > 0) 1f else -1f
        if (d <= sp * dt) { px = tx; py = ty; return true }
        px += dx / d * sp * dt
        py += dy / d * sp * dt
        return false
    }

    private fun move(dt: Float) {
        if (s.stage == "egg" || dragging || ringText != null) return
        val sp = dp(if (s.stage == "chick") 38f else 52f)
        when (mode) {
            "idle" -> {
                t -= dt
                if (t <= 0) {
                    if (hasSeed) goFood() else { pickTarget(); mode = "walk" }
                }
            }
            "walk" -> if (stepTo(dt, sp)) { mode = "idle"; t = rnd(1f, 4f) }
            "food" -> if (stepTo(dt, sp * 2.2f)) { mode = "peck"; t = 1.3f }
            "peck" -> { t -= dt; if (t <= 0) { eat(); mode = "idle"; t = 1.5f } }
            "fly" -> {
                fk += dt / fd
                val k = min(1f, fk)
                val e = if (k < 0.5f) 2 * k * k else 1 - (-2 * k + 2).pow(2) / 2
                px = fx0 + (tx - fx0) * e
                py = fy0 + (ty - fy0) * e - sin(k * PI.toFloat()) * dp(90f)
                if (k >= 1f) { mode = "idle"; t = 0.6f }
            }
        }
    }

    private fun flyRandom() {
        val b = bounds()
        fx0 = px; fy0 = py
        tx = rnd(b[0], b[2]); ty = rnd(b[1], b[3])
        fk = 0f; fd = rnd(0.9f, 1.4f)
        face = if (tx >= px) 1f else -1f
        mode = "fly"
    }

    private fun animate(now: Long) {
        val pv = petView ?: return
        var rot = 0f
        var bob = 0f
        var shake = 0f
        var wing = 0f
        val we = now - wobbleStart
        if (s.stage == "egg" && we < 900) {
            val k = we / 900f
            rot = sin(k * PI.toFloat() * 4) * 6f * (1 - k)
        }
        val se = now - shakeStart
        if (se < 450) {
            val k = se / 450f
            shake = sin(k * PI.toFloat() * 8) * 3f * (1 - k)
        }
        when {
            ringText != null -> bob = -abs(sin(now / 500f * PI.toFloat())) * 10f
            mode == "walk" || mode == "food" -> bob = -abs(sin(now / 350f * PI.toFloat())) * 3f
            mode == "peck" -> rot = 7f + 7f * sin(now / 300f * PI.toFloat())
            mode == "fly" -> wing = sin(now / 60f) * 30f
        }
        pv.rot = rot; pv.bob = bob; pv.shake = shake; pv.wing = wing; pv.face = face
        pv.invalidate()
        textView?.let { if (it.fx.isNotEmpty()) it.invalidate() }
    }

    private fun place() {
        val pv = petView ?: return
        val tv = textView ?: return
        val pl = petLp ?: return
        val tl = textLp ?: return
        val ix = px.toInt()
        val iy = py.toInt()
        if (ix == lastPx && iy == lastPy) return
        lastPx = ix; lastPy = iy
        pl.x = ix; pl.y = iy
        tl.x = (px + petPx / 2f - textW / 2f).toInt()
        tl.y = (py - topPad).toInt()
        try {
            wm.updateViewLayout(pv, pl)
            wm.updateViewLayout(tv, tl)
        } catch (_: Exception) {
        }
    }

    // ---------------- 1초 루프 ----------------
    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            Store.catchUp(this@PetService)
            if (s.stage == "egg" && now > nextWobble && !dragging) {
                wobbleStart = now
                nextWobble = now + (3000 + Random.nextInt(6000))
            }
            val rt = ringText
            if (rt != null) {
                if (now > ringEnd) stopRing(true)
                else if (now - lastBeat > 2600) { lastBeat = now; beat() }
            }
            updateVisibility()
            textView?.let {
                it.ring = ringText != null
                it.bubble = bubbleText()
                it.label = labelText()
                it.invalidate()
            }
            if (now - lastSave > 10000) {
                lastSave = now
                s.x = px; s.y = py
                Store.save()
            }
            h.postDelayed(this, 1000)
        }
    }

    private fun pad(n: Int) = n.toString().padStart(2, '0')

    private fun bubbleText(): String {
        ringText?.let { return it }
        val tt = tempText
        if (tt != null && System.currentTimeMillis() < tempUntil) return tt
        val c = Calendar.getInstance()
        val clock = "🕒 ${pad(c.get(Calendar.HOUR_OF_DAY))}:${pad(c.get(Calendar.MINUTE))}"
        if (s.stage != "egg") {
            val nx = AlarmSched.nextText(s)
            if (nx != null && (System.currentTimeMillis() / 5000) % 2 == 1L) return nx
        }
        return clock
    }

    private fun fmt(ms: Double): String {
        var sec = maxOf(0L, kotlin.math.ceil(ms / 1000).toLong())
        val d = sec / 86400; sec %= 86400
        val hh = sec / 3600
        val mm = (sec % 3600) / 60
        val ss = sec % 60
        return when {
            d > 0 -> "${d}일 ${pad(hh.toInt())}:${pad(mm.toInt())}"
            hh > 0 -> "$hh:${pad(mm.toInt())}:${pad(ss.toInt())}"
            else -> "$mm:${pad(ss.toInt())}"
        }
    }

    private fun labelText(): String {
        val r = Store.remainMs(s)
        return when (s.stage) {
            "egg" -> if (r <= 0 && s.stim < 5) "톡톡 만져주세요" else "부화 ${fmt(r)}"
            "chick" -> "성체 ${fmt(r)}"
            else -> "산란 ${fmt(r)}"
        }
    }

    private fun say(text: String, ms: Long) {
        tempText = text
        tempUntil = System.currentTimeMillis() + ms
        textView?.let { it.bubble = bubbleText(); it.invalidate() }
    }

    private fun addFx(n: Int, chars: List<String>, big: Boolean) {
        val tv = textView ?: return
        val now = System.currentTimeMillis()
        for (i in 0 until n) {
            val x = tv.petLeft() + petPx * rnd(0.15f, 0.8f)
            val y = topPad + petPx * rnd(0.0f, 0.4f)
            tv.fx.add(TextOverlay.Fx(x, y, now + i * 120L, chars[i % chars.size], big))
        }
        tv.invalidate()
    }

    private fun voice(alarm: Boolean) {
        if (s.sound) Sound.play(s.stage == "rooster", alarm)
    }

    private fun buzz(pattern: LongArray) {
        if (s.vib) Util.vibrate(this, pattern)
    }

    private fun announce(msg: String) {
        mode = "idle"; t = 1.5f
        removeSeed()
        petView?.invalidate()
        say(msg, 4500)
        addFx(5, listOf("✨", "⭐", "🎉"), true)
        voice(false)
        buzz(longArrayOf(0, 80, 60, 80))
        try {
            getSystemService(NotificationManager::class.java).notify(NOTI_PET, buildNotif())
        } catch (_: Exception) {
        }
    }

    // ---------------- 터치 ----------------
    private val longPress = Runnable {
        longFired = true
        if (dragging) return@Runnable
        Util.vibrate(this, longArrayOf(0, 20))
        if (s.stage == "egg") openApp() else feed()
    }

    private val touch = View.OnTouchListener { _, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                startPx = px; startPy = py
                moved = false; longFired = false
                h.postDelayed(longPress, 550)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!moved && hypot(dx, dy) > dp(10f)) {
                    moved = true
                    h.removeCallbacks(longPress)
                    dragging = true
                    if (mode == "fly" || mode == "walk" || mode == "food") { mode = "idle"; t = 1.5f }
                }
                if (dragging) {
                    px = clampX(startPx + dx)
                    py = clampY(startPy + dy)
                }
            }
            MotionEvent.ACTION_UP -> {
                h.removeCallbacks(longPress)
                if (dragging) {
                    dragging = false
                    s.x = px; s.y = py
                    Store.save()
                } else if (!longFired) {
                    tap()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                h.removeCallbacks(longPress)
                dragging = false
            }
        }
        true
    }

    private val loveMsgs = listOf("기분 좋아요!", "헤헤 간지러워", "또 만져주세요", "좋아요 💛", "고마워요!")

    private fun tap() {
        if (ringText != null) { stopRing(false); return }
        val now = System.currentTimeMillis()
        if (s.stage == "egg") {
            if (now - lastCare > 700) {
                s.gauge = min(100.0, s.gauge + 4)
                s.stim++
                lastCare = now
            }
            shakeStart = now
            buzz(longArrayOf(0, 25, 40, 25, 40, 25))
            addFx(1, listOf("💗"), false)
            say("고마워요 💛", 1400)
            Store.checkStage(s)
        } else {
            if (now - lastCare > 1100) {
                s.gauge = min(100.0, s.gauge + 3)
                lastCare = now
            }
            addFx(2, listOf("💗"), false)
            say(loveMsgs[Random.nextInt(loveMsgs.size)], 1500)
            voice(false)
            flyRandom()
        }
        Store.save()
        textView?.let { it.label = labelText(); it.invalidate() }
    }

    private fun openApp() {
        try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    // ---------------- 먹이 ----------------
    private fun feed() {
        if (petView == null) return
        if (s.stage == "egg") { say("병아리가 되면 먹이를 먹어요", 1800); return }
        if (hasSeed) { say("아직 먹는 중이에요", 1200); return }
        val b = bounds()
        seedX = rnd(b[0] + petPx / 2f, b[2] + petPx / 2f)
        seedY = rnd(b[1] + petPx * 0.9f, b[3] + petPx * 0.8f)
        val sl = seedLp ?: return
        val sv = seedView ?: return
        sl.x = (seedX - seedPx / 2f).toInt()
        sl.y = (seedY - seedPx / 2f).toInt()
        try { wm.updateViewLayout(sv, sl) } catch (_: Exception) {}
        sv.visibility = if (shown) View.VISIBLE else View.GONE
        hasSeed = true
        if (mode != "fly" && !dragging) goFood()
    }

    private fun goFood() {
        tx = clampX(seedX - petPx / 2f)
        ty = clampY(seedY - petPx * 0.85f)
        mode = "food"
    }

    private fun removeSeed() {
        hasSeed = false
        seedView?.visibility = View.GONE
    }

    private fun eat() {
        if (!hasSeed) return
        removeSeed()
        s.gauge = min(100.0, s.gauge + 8)
        addFx(3, listOf("💗"), false)
        say("냠냠! 맛있어요 🌾", 1600)
        buzz(longArrayOf(0, 30))
        Store.save()
    }

    // ---------------- 알람 울림 ----------------
    private fun startRing(id: String?) {
        val a = s.alarms.find { it.id == id } ?: return
        if (s.stage == "egg") { if (!s.petOn) stopSelf(); return }
        val cry = if (s.stage == "rooster") "꼬끼오!" else "삐약!"
        val msg = when (a.type) {
            "기상" -> "일어날 시간이에요"
            "일정" -> "일정 시간이에요"
            else -> "알람이에요"
        }
        val icon = Store.ICON[a.type] ?: "⏰"
        val text = "$icon ${a.time} ${a.label.ifEmpty { msg }} $cry"
        ringText = text
        ringEnd = System.currentTimeMillis() + 120_000
        lastBeat = System.currentTimeMillis()
        beat()
        updateVisibility()
        textView?.let { it.ring = true; it.bubble = text; it.invalidate() }
        try {
            val n = Notification.Builder(this, CH_ALARM)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("꼬꼬 다마고찌 $cry")
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setContentIntent(svcIntent(ACT_STOPRING, 13))
                .setDeleteIntent(svcIntent(ACT_STOPRING, 14))
                .addAction(
                    Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat), "끄기", svcIntent(ACT_STOPRING, 15)
                    ).build()
                )
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(NOTI_RING, n)
        } catch (_: Exception) {
        }
    }

    private fun beat() {
        voice(true)
        buzz(longArrayOf(0, 300, 150, 300))
    }

    private fun stopRing(silent: Boolean) {
        if (ringText == null) return
        ringText = null
        try { getSystemService(NotificationManager::class.java).cancel(NOTI_RING) } catch (_: Exception) {}
        if (!silent) say("확인했어요! 😊", 1500)
        textView?.let { it.ring = false; it.invalidate() }
        if (!s.petOn) stopSelf()
    }

    // ---------------- 홈 화면에서만 보이기 ----------------
    private fun updateVisibility() {
        val show = ringText != null || !s.homeOnly || !Util.hasUsage(this) || isHome()
        if (show == shown) return
        shown = show
        val v = if (show) View.VISIBLE else View.GONE
        petView?.visibility = v
        textView?.visibility = v
        seedView?.visibility = if (show && hasSeed) View.VISIBLE else View.GONE
        // 숨겨진 동안에는 펫 창이 터치를 가로채지 않도록
        val pl = petLp ?: return
        pl.flags = if (show) WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { petView?.let { wm.updateViewLayout(it, pl) } } catch (_: Exception) {}
    }

    private fun isHome(): Boolean {
        try {
            val usm = getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - 10_000, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == 1) lastFg = e.packageName   // 1 = 앱이 앞으로 나옴
            }
        } catch (_: Exception) {
        }
        val fg = lastFg ?: return true
        return fg == launcherPkg || fg == packageName
    }
}
