package com.haessal.kkoko

import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Util {
    fun vibrate(ctx: Context, pattern: LongArray) {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (!v.hasVibrator()) return
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (_: Exception) {
        }
    }

    fun hasUsage(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(AppOpsManager::class.java)
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            } else {
                @Suppress("DEPRECATION")
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }
}

/** "삐약" / "꼬끼오" 소리를 코드로 합성해서 재생 */
object Sound {
    private const val SR = 22050
    private var peepBuf: ShortArray? = null
    private var crowBuf: ShortArray? = null

    // part = [시작초, 시작Hz, 끝Hz, 길이초, 볼륨, 떨림Hz]
    private fun synth(total: Double, parts: List<DoubleArray>, saw: Boolean, lowpass: Boolean): ShortArray {
        val n = (total * SR).toInt()
        val buf = DoubleArray(n)
        for (pt in parts) {
            val start = (pt[0] * SR).toInt()
            val f0 = pt[1]; val f1 = pt[2]; val dur = pt[3]; val vol = pt[4]; val vib = pt[5]
            val len = (dur * SR).toInt()
            var phase = 0.0
            for (i in 0 until len) {
                val idx = start + i
                if (idx >= n) break
                val tt = i.toDouble() / SR
                val k = tt / dur
                var f = f0 * (f1 / f0).pow(k)
                if (vib > 0) f *= 1 + 0.05 * sin(2 * PI * vib * tt)
                phase += f / SR
                val ph = phase - floor(phase)
                val w = if (saw) 2 * ph - 1 else sin(2 * PI * ph)
                val env = min(1.0, tt / 0.02) * (1 - k).pow(0.6)
                buf[idx] += w * vol * env
            }
        }
        if (lowpass) {
            var y = 0.0
            for (i in buf.indices) { y += 0.35 * (buf[i] - y); buf[i] = y }
        }
        return ShortArray(n) { (max(-1.0, min(1.0, buf[it])) * 30000).toInt().toShort() }
    }

    private fun peep(): ShortArray = peepBuf ?: synth(
        0.35,
        listOf(
            doubleArrayOf(0.0, 2800.0, 4300.0, 0.11, 0.55, 0.0),
            doubleArrayOf(0.17, 3000.0, 4500.0, 0.13, 0.55, 0.0)
        ), saw = false, lowpass = false
    ).also { peepBuf = it }

    private fun crow(): ShortArray = crowBuf ?: synth(
        1.5,
        listOf(
            doubleArrayOf(0.0, 520.0, 780.0, 0.18, 0.5, 30.0),
            doubleArrayOf(0.2, 780.0, 720.0, 0.14, 0.5, 30.0),
            doubleArrayOf(0.36, 720.0, 1000.0, 0.3, 0.55, 26.0),
            doubleArrayOf(0.68, 1000.0, 560.0, 0.75, 0.5, 22.0)
        ), saw = true, lowpass = true
    ).also { crowBuf = it }

    fun play(rooster: Boolean, alarm: Boolean) {
        try {
            val data = if (rooster) crow() else peep()
            val attr = AudioAttributes.Builder()
                .setUsage(if (alarm) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val fmt = AudioFormat.Builder()
                .setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack(attr, fmt, data.size * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE)
            track.write(data, 0, data.size)
            track.play()
            Handler(Looper.getMainLooper()).postDelayed({
                try { track.release() } catch (_: Exception) {}
            }, data.size * 1000L / SR + 300)
        } catch (_: Exception) {
        }
    }
}

/** 알람·일정·기상 알림을 AlarmManager에 등록 (폰이 잠들어 있어도 울리도록) */
object AlarmSched {
    fun occurrence(a: Alarm, after: Long): Long? {
        return try {
            val hm = a.time.split(":")
            val hh = hm[0].toInt()
            val mm = hm[1].toInt()
            val c = Calendar.getInstance()
            if (a.type == "일정") {
                val d = a.date.split("-")
                c.set(d[0].toInt(), d[1].toInt() - 1, d[2].toInt(), hh, mm, 0)
                c.set(Calendar.MILLISECOND, 0)
                if (c.timeInMillis > after) c.timeInMillis else null
            } else {
                c.timeInMillis = after
                c.set(Calendar.HOUR_OF_DAY, hh)
                c.set(Calendar.MINUTE, mm)
                c.set(Calendar.SECOND, 0)
                c.set(Calendar.MILLISECOND, 0)
                if (c.timeInMillis <= after) c.add(Calendar.DAY_OF_YEAR, 1)
                c.timeInMillis
            }
        } catch (_: Exception) {
            null
        }
    }

    fun next(s: PetState, after: Long): Pair<Alarm, Long>? {
        var best: Pair<Alarm, Long>? = null
        for (a in s.alarms) {
            if (!a.on) continue
            val t = occurrence(a, after) ?: continue
            if (best == null || t < best.second) best = Pair(a, t)
        }
        return best
    }

    fun nextText(s: PetState): String? {
        val n = next(s, System.currentTimeMillis()) ?: return null
        val a = n.first
        val icon = Store.ICON[a.type] ?: "⏰"
        val datePart = if (a.type == "일정") {
            val c = Calendar.getInstance(); c.timeInMillis = n.second
            "${c.get(Calendar.MONTH) + 1}/${c.get(Calendar.DAY_OF_MONTH)} "
        } else ""
        return "$icon $datePart${a.time} ${a.label.ifEmpty { a.type }}"
    }

    fun schedule(ctx: Context, after: Long = System.currentTimeMillis()) {
        val s = Store.s(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val best = next(s, after)
        val intent = Intent(ctx, AlarmReceiver::class.java)
        if (best != null) intent.putExtra("id", best.first.id)
        val pi = PendingIntent.getBroadcast(
            ctx, 100, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (best == null) {
            am.cancel(pi)
            return
        }
        val show = PendingIntent.getActivity(
            ctx, 101, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(best.second, show), pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best.second, pi)
        }
    }
}
