package com.haessal.kkoko

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import kotlin.math.min

/** 펫 그림 (터치를 받는 창) — 80×80 단위 안에 64×64 스프라이트를 그린다 */
class PetView(ctx: Context) : View(ctx) {
    var rot = 0f
    var shake = 0f
    var bob = 0f
    var wing = 0f
    var face = 1f

    override fun onDraw(c: Canvas) {
        val s = Store.s(context)
        c.save()
        val sc = width / 80f
        c.scale(sc, sc)
        c.translate(8f + shake, 14f + bob)
        c.rotate(rot, 32f, 58f)
        c.scale(face, 1f, 32f, 32f)
        when (s.stage) {
            "egg" -> Sprites.egg(c, s.mult, s.prog / Store.need(s) > 0.75)
            "chick" -> Sprites.chick(c, s.tier, wing)
            else -> Sprites.rooster(c, s.tier, wing)
        }
        c.restore()
    }
}

/** 말풍선·남은 시간·하트를 그리는 창 (터치는 통과) */
class TextOverlay(ctx: Context, private val petPx: Int, private val topPad: Int) : View(ctx) {
    var bubble = ""
    var ring = false
    var label = ""

    class Fx(val x: Float, val y: Float, val start: Long, val ch: String, val big: Boolean)

    val fx = mutableListOf<Fx>()

    private val d = resources.displayMetrics.density
    private val bp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = Color.parseColor("#1F2937")
    }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = 0x33000000
    }
    private val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 11.5f * d
        setShadowLayer(3f * d, 0f, d, 0xCC000000.toInt())
    }
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val r = RectF()
    private val tri = Path()

    fun petLeft(): Float = (width - petPx) / 2f

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        if (bubble.isNotEmpty()) {
            bp.textSize = (if (ring) 14.5f else 13f) * d
            val padH = 10f * d
            val padV = 6f * d
            val text = TextUtils.ellipsize(bubble, bp, width - 2 * padH - 8 * d, TextUtils.TruncateAt.END).toString()
            val tw = bp.measureText(text)
            val fm = bp.fontMetrics
            val th = fm.descent - fm.ascent
            val bottom = topPad - 8f * d
            val top = bottom - th - 2 * padV
            r.set(cx - tw / 2 - padH, top, cx + tw / 2 + padH, bottom)
            bg.color = if (ring) Color.parseColor("#FFF4C2") else Color.WHITE
            val rad = 14f * d
            c.drawRoundRect(r, rad, rad, bg)
            c.drawRoundRect(r, rad, rad, border)
            tri.reset()
            tri.moveTo(cx - 6 * d, bottom - 1)
            tri.lineTo(cx + 6 * d, bottom - 1)
            tri.lineTo(cx, bottom + 6 * d)
            tri.close()
            c.drawPath(tri, bg)
            c.drawText(text, cx - tw / 2, top + padV - fm.ascent, bp)
        }
        if (label.isNotEmpty()) {
            c.drawText(label, cx, topPad + petPx + 14f * d, lp)
        }
        if (fx.isNotEmpty()) {
            val now = System.currentTimeMillis()
            val it = fx.iterator()
            while (it.hasNext()) {
                val f = it.next()
                val k = (now - f.start) / 1100f
                if (k < 0f) continue
                if (k > 1f) { it.remove(); continue }
                fp.textSize = (if (f.big) 22f else 16f) * d * (1f + 0.3f * k)
                fp.alpha = (255 * min(1f, 1.2f - k)).toInt().coerceIn(0, 255)
                c.drawText(f.ch, f.x, f.y - 46f * d * k, fp)
            }
        }
    }
}

/** 먹이 */
class SeedView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    override fun onDraw(c: Canvas) {
        p.textSize = height * 0.7f
        c.drawText("🌾", width / 2f, height * 0.78f, p)
    }
}
