package com.haessal.kkoko

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.round

data class Alarm(
    val id: String,
    var type: String,      // 기상 / 알람 / 일정
    var time: String,      // HH:mm
    var date: String,      // yyyy-MM-dd (일정만)
    var label: String,
    var on: Boolean
)

class PetState {
    var stage = "egg"          // egg / chick / rooster
    var gen = 1
    var prog = 0.0             // 현재 단계에서 지난 '게임 시간'(ms)
    var gauge = 30.0           // 정성(알) / 애정(병아리·닭) 0~100
    var aSum = 0.0             // 평균 계산용
    var aT = 0.0
    var stim = 0               // 알 자극 횟수
    var tier = "mid"           // high / mid / low
    var mult = 1.0             // 이 알의 부화 시간 배수
    var x = -1f
    var y = -1f
    var sound = true
    var vib = true
    var speed = "fast"
    var homeOnly = false
    var petOn = true
    var last = System.currentTimeMillis()
    val alarms = mutableListOf<Alarm>()
}

object Store {
    const val H = 3600_000.0
    val SPEED = linkedMapOf("real" to 1.0, "fast" to 60.0, "demo" to 1440.0)
    val SPEED_NAME = mapOf(
        "real" to "실제  (알 24시간 · 병아리 3일 · 산란 2일)",
        "fast" to "빠름 ×60  (알 24분 · 병아리 72분 · 산란 48분)",
        "demo" to "시연 ×1440  (알 1분 · 병아리 3분 · 산란 2분)"
    )
    val ICON = mapOf("기상" to "🌅", "알람" to "⏰", "일정" to "📅")
    private val TIER_NAME = mapOf(
        "chick" to mapOf("high" to "튼튼한 병아리", "mid" to "보통 병아리", "low" to "허약한 병아리"),
        "rooster" to mapOf("high" to "늠름한 수탉", "mid" to "보통 수탉", "low" to "꼬마 수탉")
    )

    private var st: PetState? = null
    private var app: Context? = null
    var onEvent: ((String) -> Unit)? = null

    fun s(ctx: Context): PetState {
        if (st == null) {
            app = ctx.applicationContext
            st = load(ctx.applicationContext)
        }
        return st!!
    }

    fun speedF(s: PetState): Double = SPEED[s.speed] ?: 60.0

    fun need(s: PetState): Double = when (s.stage) {
        "egg" -> 24 * H * s.mult
        "chick" -> 72 * H
        else -> 48 * H
    }

    fun avg(s: PetState): Double = if (s.aT > 0) s.aSum / s.aT else s.gauge

    fun tierOf(a: Double): String = if (a >= 70) "high" else if (a >= 40) "mid" else "low"

    fun remainMs(s: PetState): Double = (need(s) - s.prog) / speedF(s)

    fun eggName(s: PetState): String =
        if (s.gen == 1) "알" else if (s.mult < 0.8) "황금알" else if (s.mult > 1.2) "느긋한 알" else "보통 알"

    fun stageName(s: PetState): String =
        if (s.stage == "egg") eggName(s) else TIER_NAME[s.stage]?.get(s.tier) ?: s.stage

    fun tierName(stage: String, tier: String): String = TIER_NAME[stage]?.get(tier) ?: ""

    /** 마지막 기록 이후 흐른 시간만큼 성장을 진행 */
    fun catchUp(ctx: Context) {
        val s = s(ctx)
        val now = System.currentTimeMillis()
        val dt = now - s.last
        s.last = now
        if (dt <= 0) return
        val g = dt * speedF(s)
        val g0 = s.gauge
        val g1 = max(0.0, g0 - g * 2.0 / H)   // 게임시간 1시간마다 2씩 감소
        s.aSum += (g0 + g1) / 2.0 * g
        s.aT += g
        s.gauge = g1
        s.prog += g
        checkStage(s)
    }

    fun checkStage(s: PetState) {
        if (s.prog < need(s)) return
        when (s.stage) {
            "egg" -> {
                if (s.stim < 5) return
                s.tier = tierOf(avg(s))
                setStage(s, "chick")
                onEvent?.invoke("부화했어요! 삐약! 🐣")
            }
            "chick" -> {
                s.tier = tierOf(avg(s))
                setStage(s, "rooster")
                onEvent?.invoke("어른 닭이 되었어요! 꼬끼오!")
            }
            else -> {
                val a = avg(s)
                s.mult = round((1.5 - a / 100.0) * 100.0) / 100.0
                s.gen++
                setStage(s, "egg")
                onEvent?.invoke("알을 낳았어요! 🥚")
            }
        }
        save()
    }

    private fun setStage(s: PetState, stage: String) {
        s.stage = stage
        s.prog = 0.0
        s.gauge = if (stage == "egg") 30.0 else 40.0
        s.aSum = 0.0
        s.aT = 0.0
        s.stim = 0
    }

    fun reset(ctx: Context) {
        val old = s(ctx)
        val n = PetState()
        n.sound = old.sound; n.vib = old.vib; n.speed = old.speed
        n.homeOnly = old.homeOnly; n.petOn = old.petOn
        n.alarms.addAll(old.alarms)
        st = n
        save()
    }

    fun save() {
        val s = st ?: return
        val c = app ?: return
        val o = JSONObject()
        o.put("stage", s.stage); o.put("gen", s.gen); o.put("prog", s.prog)
        o.put("gauge", s.gauge); o.put("aSum", s.aSum); o.put("aT", s.aT)
        o.put("stim", s.stim); o.put("tier", s.tier); o.put("mult", s.mult)
        o.put("x", s.x.toDouble()); o.put("y", s.y.toDouble())
        o.put("sound", s.sound); o.put("vib", s.vib); o.put("speed", s.speed)
        o.put("homeOnly", s.homeOnly); o.put("petOn", s.petOn); o.put("last", s.last)
        val arr = JSONArray()
        for (a in s.alarms) {
            val ao = JSONObject()
            ao.put("id", a.id); ao.put("type", a.type); ao.put("time", a.time)
            ao.put("date", a.date); ao.put("label", a.label); ao.put("on", a.on)
            arr.put(ao)
        }
        o.put("alarms", arr)
        c.getSharedPreferences("kkoko", Context.MODE_PRIVATE).edit().putString("state", o.toString()).apply()
    }

    private fun load(c: Context): PetState {
        val s = PetState()
        val str = c.getSharedPreferences("kkoko", Context.MODE_PRIVATE).getString("state", null) ?: return s
        try {
            val o = JSONObject(str)
            s.stage = o.optString("stage", "egg")
            s.gen = o.optInt("gen", 1)
            s.prog = o.optDouble("prog", 0.0)
            s.gauge = o.optDouble("gauge", 30.0)
            s.aSum = o.optDouble("aSum", 0.0)
            s.aT = o.optDouble("aT", 0.0)
            s.stim = o.optInt("stim", 0)
            s.tier = o.optString("tier", "mid")
            s.mult = o.optDouble("mult", 1.0)
            s.x = o.optDouble("x", -1.0).toFloat()
            s.y = o.optDouble("y", -1.0).toFloat()
            s.sound = o.optBoolean("sound", true)
            s.vib = o.optBoolean("vib", true)
            s.speed = o.optString("speed", "fast")
            s.homeOnly = o.optBoolean("homeOnly", false)
            s.petOn = o.optBoolean("petOn", true)
            s.last = o.optLong("last", System.currentTimeMillis())
            val arr = o.optJSONArray("alarms")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val a = arr.getJSONObject(i)
                    s.alarms.add(
                        Alarm(
                            a.optString("id"), a.optString("type", "알람"), a.optString("time", "07:00"),
                            a.optString("date", ""), a.optString("label", ""), a.optBoolean("on", true)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            return PetState()
        }
        return s
    }
}
